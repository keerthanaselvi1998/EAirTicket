package org.cts.service;
import org.cts.bean.Updation;

public interface UpdateService {
public boolean CustomerUpdationService(Updation updation);
}
