package org.cts.service;


public interface EditService {

       public int editServicer(String n);
}

