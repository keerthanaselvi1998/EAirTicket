package org.cts.dao;

import org.cts.bean.Cancel;

public interface CancelDao {
int cancelSeat(Cancel c);
}
