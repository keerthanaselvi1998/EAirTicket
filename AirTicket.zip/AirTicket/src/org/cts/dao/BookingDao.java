package org.cts.dao;

import org.cts.bean.Booking;

public interface BookingDao {

boolean bookSeat(Booking b);

}
