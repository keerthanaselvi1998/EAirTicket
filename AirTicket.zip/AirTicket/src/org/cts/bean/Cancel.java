package org.cts.bean;

public class Cancel {
private int bookid;
public Cancel(int bookid)
{
	this.bookid=bookid;
}
public int getBookid() {
	return bookid;
}
public void setBookid(int bookid) {
	this.bookid = bookid;
}
}
